package cdac3;

public class Question03_calling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Question03 qa=new Question03();
		qa.accept();
		
		qa.displayAllProducts();

	}

}
