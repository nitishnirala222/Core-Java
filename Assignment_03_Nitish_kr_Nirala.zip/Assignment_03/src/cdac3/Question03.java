package cdac3;
import java.util.*;
public class Question03 {
	Scanner sc=new Scanner(System.in);
	private String[] arr=new String[4];
	
	public String accept()
	{
		System.out.println("enter 4 product's name: ");
		for(int i=0;i<4;i++) {
		arr[i]=sc.next();
		}
		return null;
	
	}
	public void displayAllProducts()
	{
	System.out.println("The 4 products are: ");	
		for(int i=0;i<4;i++)
			System.out.println(arr[i]);
	}
}
