package cdac3;

public class Question02_Calling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Question02A q=new Question02A("Car",500000);
		q.display();
		Question02A q2=new Question02A("Bike",100000);
		q2.display();
		Question02A q3=new Question02A("Mobile",20000);
		q3.display();
		
		System.out.println("_____________________Question02B Calling________________________");
		
		Question02B qq=new Question02B("computer",150000);
		System.out.println("Product's Name: "+qq.getAccessoryProduct());

	}

}
