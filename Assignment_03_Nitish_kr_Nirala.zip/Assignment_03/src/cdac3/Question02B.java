package cdac3;

public class Question02B {

		private static int productId;
		private String productName;
		private int productPrice;
		public Question02B() {}
		public Question02B(String productName,int productPrice)
		{
		this.productName=productName;
		this.productPrice=productPrice;
		}
		public void display()
		{
			System.out.println(productId+" "+productName+" "+productPrice);
		}
		
		static{					//static initialization block
			productId=100;
			
		}
		
		{					//instance initialization block
			productId++;
		}
		public String getAccessoryProduct()
		{
		return productName;	
		}
	}



