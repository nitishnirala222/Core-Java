package cdac3;

public class Question01_Calling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("_____________________Question01A Calling______________________________");
		Question01A q1=new Question01A(100,"computer",80000);
		q1.display();
		System.out.println("The price of "+q1.getProductName()+" is "+q1.getProductPrice());
		q1.SetPrice(90000);
		System.out.println("The price of "+q1.getProductName()+" is "+q1.getProductPrice());
		q1.SetId(105);
		System.out.println("productId: "+q1.getProductId()+", productName: "+q1.getProductName()+", productPrice: "+q1.getProductPrice());
		Question01A q2=new Question01A(101,"Ice-cream",100);
		q2.display();
		
		Question01A q3=new Question01A();
		q3.SetId(1001);
		q3.SetName("laptop");
		q3.SetPrice(60000);
		q3.display();
		
		System.out.println("_____________________________Question02 Calling____________________________");
		
		Question01B q=new Question01B();
		q.main();
		
	}


}
