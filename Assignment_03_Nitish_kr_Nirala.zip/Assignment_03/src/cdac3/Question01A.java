package cdac3;

public class Question01A {
	private int productId;
	private String productName;
	private int productPrice;
	public Question01A() {}
	public Question01A(int productId,String productName,int productPrice)
	{
	this.productId=productId;
	this.productName=productName;
	this.productPrice=productPrice;
	}
	
	public void SetId(int id)   //mutator
	{
	productId=id;
	}
	public void SetName(String name)
	{
		productName=name;
	}
	public void SetPrice(int price)
	{
		productPrice=price;
	}
	public int getProductId()    //accessor
	{
	return productId;	
	}
	public String getProductName()
	{
		return productName;
	}
	public int getProductPrice()
	{
		return productPrice;
	}
	public void display()
	{
		System.out.println(productId+" "+productName+" "+productPrice);
	}
	
}
