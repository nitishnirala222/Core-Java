
public class Shape_Calling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Circle c=new Circle();
		 c.SetCircle();
		 System.out.println("The Area of circle is: "+c.getCircleArea());
		 System.out.println("The perimeter of circle is: "+c.getCircleParameter());
		 
		Rectangle r=new Rectangle();
		r.SetRectangle();
		System.out.println("The Area of a Rectangle is: "+r.getRectArea());
		System.out.println("The Perimeter of a Rectangle is: "+r.getRectParameter());
		

		
		Sphere s=new Sphere();
		s.setSphere();
		System.out.println("The Area of Sphere is: "+s.getSphereArea());
		System.out.println("The Perimeter of a Sphere is: "+s.getSphereParameter());
		
		Cuboid cb =new Cuboid();
		cb.setCuboid();
		System.out.println("The Area of Cuboid is: "+cb.getCuboidArea());
		System.out.println("The Perimeter of a Cuboid is: "+cb.getCuboidParameter());
		
	}

}
