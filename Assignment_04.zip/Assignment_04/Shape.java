
import java.util.*;
abstract class Shape {
 Scanner sc=new Scanner(System.in);
	
	
}
abstract class Shape2D extends Shape {
	
}

class Circle extends Shape2D
{
	private int r;
public void SetCircle()
{
System.out.print("enter the radius of a circle: ");
r=sc.nextInt();
}
public double getCircleParameter()
{
return (2*3.14*r);	
}
public double getCircleArea()
{
	return (3.14*r*r); 
}
}

class Rectangle extends Shape2D
{
private int a,b;
public void SetRectangle()
{
	System.out.print("enter width of a rectangle: ");
	a=sc.nextInt();
	System.out.print("enter length of a rectangle: ");
	b=sc.nextInt();
}
public int getRectParameter()
{
	return 2*(a+b);
}
public int getRectArea()
{
	return a*b;
}
}

abstract class Shape3D extends Shape {

}	

class Sphere extends Shape3D{
	private int r;
public void setSphere() 
{
System.out.print("enter radius of a sphere: ");
r=sc.nextInt();
}
public double getSphereParameter()
{
	return (4*3.14*r*r);
}
public double getSphereArea()
{
	return (4/3*3.14*r*r*r);
}
}

class Cuboid extends Shape3D{
private int w,h,l;
public void setCuboid()
{
	System.out.print("enter the width of cuboid: ");
	w=sc.nextInt();
	System.out.print("enter the length of cuboid: ");
	l=sc.nextInt();
	System.out.print("enter the height of cuboid: ");
	h=sc.nextInt();
}
public int getCuboidArea()
{
return 2*(l*w+w*h+l*h);	
}
public int getCuboidParameter()
{
return 4*(l+w+h);	
}
}


