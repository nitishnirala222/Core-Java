
import java.util.*;
public class ShapeB {
	
	Scanner sc=new Scanner(System.in);
		public int[] arr = new int[5];
		
		public void SetArray()
		{
			System.out.println("enter 5 numbers in an array: ");
			for(int i=0;i<5;i++)
			{
				arr[i]=sc.nextInt();
			}
		}
		
		public void display()
		{
			System.out.println("parent class Array");
		for(int i=0;i<5;i++)
			System.out.print(arr[i]+" ");
		}
		
}

class DeriveB extends ShapeB{

	public void display()
	{	
		System.out.println("Child class Array");
		for(int i=0;i<5;i++)
			System.out.print(arr[i]+" ");
	}
}