

public class ShapeB_Calling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ShapeB b=new DeriveB();
		b.SetArray();
		b.display();

	}

}
