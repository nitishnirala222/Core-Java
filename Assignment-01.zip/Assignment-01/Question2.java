package cdac;
import java.util.*;
public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n,a,amt1,amt2,amt3,amt4;
		char ch;
		do {
		System.out.println("1. for 1-100 units");
		System.out.println("2. for 101-200 units");
		System.out.println("3. for 201-500 units");
		System.out.println("4. for 501 onward units");
		System.out.println("5. for exit");
		
		System.out.println("enter your choice:");
		n=sc.nextInt();
		System.out.println("enter your electricity units: ");
		a=sc.nextInt();
		
		switch(n)
		{
		case 1:
			amt1=a*6;
			System.out.println("The amount of electricity bill: "+amt1);
			break;
		case 2:
			amt2=a*7;
			System.out.println("The amount of electricity bill: "+amt2);
			break;
		case 3:
			amt3=a*8;
			System.out.println("The amount of electricity bill: "+amt3);
			break;
		case 4:
			amt4=a*9;
			System.out.println("The amount of electricity bill: "+amt4);
			break;
		case 5:
			System.exit(0);
			break;
		default:
			System.out.println("invalid option");	
		}
		System.out.println("Do you want to continue[y/n]: ");
		ch=sc.next().charAt(0);
		}while(ch=='y' || ch=='Y');
				
	}

}
