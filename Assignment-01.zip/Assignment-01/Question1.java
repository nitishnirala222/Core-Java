package cdac;

import java.util.*;
import java.lang.*;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a,b,c;
		char ch;
		do {
		System.out.println("enter 1st number: ");
		a=sc.nextInt();
		System.out.println("enter 2nd number: ");
		b=sc.nextInt();
		System.out.println("enter 3rd number: ");
		c=sc.nextInt();
		
		if(a>b && a>c)
			System.out.println("The Greatest number is "+a);
		else if(b>c)
			System.out.println("The Greatest number is "+b);
		else
			System.out.println("The Greatest number is "+c);
		
		System.out.println("Do you want to continue[y/n]: ");
		ch=sc.next().charAt(0);
		
		} while(ch=='y'|| ch=='Y');	
	}
}
