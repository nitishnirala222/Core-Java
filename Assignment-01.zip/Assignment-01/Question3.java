
package cdac;
import java.util.*;
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a,b,count=0,i;
		System.out.println("enter the initial range: ");
		a=sc.nextInt();
		System.out.println("enter the end range: ");
		b=sc.nextInt();
				
		for(i=a;i<=b;i++)
		{
			count=0;
			for(int j=2;j<=i;j++) {
				if(i%j==0)
					count++;
			}
			if(count>1) {
				System.out.println("The number "+i+" is not prime number");
			}
			else
			{
				System.out.println("The number "+i+" is prime number");
			}
		}
		
	}

}
