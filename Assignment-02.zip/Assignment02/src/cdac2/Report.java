package cdac2;
import java.util.*;
public class Report {
	private
	int admno,average;
	String name;
	int[] marks=new int[5];
	
	void get_Average(int arr[])
	{
		int sum=0;
		for(int i=0;i<5;i++)
			sum+=arr[i];
		average=sum/5;
	}
	public
	void read_info()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student's admission number: ");
		admno=sc.nextInt();
		System.out.println("enter student's name: ");
		name=sc.next();
		System.out.println("enter marks of Phy, chem, math, Eng and Hindi respectively: ");
		for(int i=0;i<5;i++) 
		marks[i]=sc.nextInt();
		get_Average(marks);
	}
	void display_info()
	{	
		System.out.println("=============Student's Summary=========================");
		System.out.println("Students's admission no: "+admno);
		System.out.println("Student's name: "+name);
		System.out.println("Student's average marks: "+average);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Report r=new Report();
		r.read_info();
		r.display_info();
	}

}
