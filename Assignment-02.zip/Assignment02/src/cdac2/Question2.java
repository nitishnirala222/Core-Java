package cdac2;
import java.util.*;
public class Question2 {
	
	public int Animals(int x, int y, int z)
	{
		int total;
		total= 2*x+4*y+4*z;
		return total;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a,b,c;
		System.out.println("enter no. of chickens: ");
		a=sc.nextInt();
		System.out.println("enter no. of cows: ");
		b=sc.nextInt();
		System.out.println("enter no. of pigs: ");
		c=sc.nextInt();
		Question2 q2=new Question2();
		System.out.println("The total no. of legs of all the animals: "+q2.Animals(a,b,c));
		

	}

}
