package cdac2;
import java.util.*;
public class Question01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int s,itax,adl;
		System.out.println("enter employee's salary: ");
		s=sc.nextInt();
		
		if(s<=50000)
			System.out.println("Income Tax is Nil");
		else if(50000<s && s<=60000)
		{
			adl=s-50000;
			itax=adl*10/100;
			System.out.println("The Income tax is "+itax);
		}
		else if(60000<s && s<=150000)
		{
			adl=s-60000;
			itax=adl*20/100;
			System.out.println("The Income tax is "+itax);	
		}
		else
		{
			adl=s-150000;
			itax=adl*30/100;
			System.out.println("The Income tax is "+itax);
		}

	}

}
