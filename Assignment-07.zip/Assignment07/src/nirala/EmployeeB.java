package nirala;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class EmployeeB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList list=new ArrayList<String>();
		list.add("nitish");
		list.add("nirala");
		list.add("NCE");
		list.add("CDAC");
		list.add("Patna");
		
		HashSet<String> hashset=new HashSet<>();
		hashset.addAll(list);
		
		
		Iterator<String> iterator=hashset.iterator();
		while(iterator.hasNext())
			System.out.println(iterator.next());

	}

}
