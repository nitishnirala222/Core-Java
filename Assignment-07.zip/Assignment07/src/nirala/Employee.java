package nirala;

import java.util.ArrayList;

public class Employee {
	
	String ArrayList[]= {"nitish","nirala","NCE","CDAC","Patna"};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp=new Employee();
		for(int i=0;i<emp.ArrayList.length;i++)
		{
			System.out.println(emp.ArrayList[i]);
		}

	}

}
