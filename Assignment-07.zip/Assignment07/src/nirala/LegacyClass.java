package nirala;

import java.util.*;

public class LegacyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Vector<String> vec=new Vector<String>();
		int n;
		System.out.println("How many strings you want to enter: ");
		n=sc.nextInt();
		System.out.println("enter "+n+" strings: ");
		for(int i=0;i<n;i++)
		{
			vec.add(sc.next());
		}
		
		Enumeration<String> data=vec.elements();
		while(data.hasMoreElements())
		{
			System.out.println(data.nextElement());
		}

	}

}
