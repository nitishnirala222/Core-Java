package nirala;
import java.util.*;
public class CollectionFrameW {

	private String name,dob;
	private int roll,percent;
	public CollectionFrameW(String name,int roll,int percent,String dob)
	{
	this.name=name;
	this.roll=roll;
	this.percent=percent;
	this.dob=dob;
	}
	public void display()
	{
		System.out.println("Name: "+name);
		System.out.println("Roll: "+roll);
		System.out.println("percentage: "+percent);
		System.out.println("Date of Birth: "+dob);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1. By Name");
		System.out.println("2. By Roll Number");
		System.out.println("3. By Percentage");
		System.out.println("4. By Date of Birth");
		System.out.println("5. Exit");
		
		String nm,db;
		int r,p,n;
		CollectionFrameW obj=new CollectionFrameW("nitish",1001,90,"02/05/1999");
		System.out.print("enter your choice: ");
		n=sc.nextInt();
		
		switch(n)
		{
		case 1:
			System.out.println("enter your name: ");
			nm=sc.next();
			if(nm.equals(obj.name))
				obj.display();
			else
				System.out.println(nm+" not found.");
			break;
		case 2:
			System.out.println("enter your rollNo: ");
			r=sc.nextInt();
			if(r==obj.roll)
				obj.display();
			else
				System.out.println(r+" not found.");
			break;
		case 3:
			System.out.println("enter your percentage: ");
			p=sc.nextInt();
			if(p==obj.percent)
				obj.display();
			else
				System.out.println(p+" not found.");
			break;
		case 4:
			System.out.println("enter Date of Birth: ");
			db=sc.next();
			if(db.equals(obj.dob))
				obj.display();
			else
				System.out.println(db+" not found.");
			break;
		case 5:
			System.exit(0);
			break;
			default:
				System.out.println("invalid choice");
		}
		
	}


}
