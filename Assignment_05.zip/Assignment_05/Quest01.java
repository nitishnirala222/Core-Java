
import java.util.*;
interface Product{       //interface declaration
	void display();
}

class AcceptProduct implements Product{ 		
	
	Scanner sc=new Scanner(System.in);
	private String elect, food, gadget;
	public void SetProduct()
	{
		System.out.println("enter a electronic prduct: ");
		elect=sc.nextLine();
		System.out.println("enter a food product: ");
		food=sc.nextLine();
		System.out.println("enter a gadget product: ");
		gadget=sc.nextLine();
		System.out.println("____________________________________________________");
	}
	public void display()
	{
	System.out.println("electronic product: "+elect);
	System.out.println("food product product: "+food);
	System.out.println("gadget product: "+gadget);
	System.out.println("____________________________________________________");
	}
}
class ProductPrice implements Product		
{
	Scanner sc=new Scanner(System.in);
	private int ep,fp,gp;
	public ProductPrice(int ep,int fp,int gp)
	{
	this.ep=ep;
	this.fp=fp;
	this.gp=gp;
	}
	public void UpdatePrice()
	{
	System.out.println("update electronic product's price: ");
	ep=sc.nextInt();
	System.out.println("update food product's price: ");
	fp=sc.nextInt();
	System.out.println("update gadget product's price: ");
	gp=sc.nextInt();
	System.out.println("____________________________________________________");
	}
	public void display()
	{
		System.out.println("The electronic's price is: "+ep);
		System.out.println("The food's price is: "+fp);
		System.out.println("The gadget's price is: "+gp);	
		System.out.println("____________________________________________________");
	}
}
public class Quest01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AcceptProduct ap=new AcceptProduct();
		ap.SetProduct();
		ap.display();
		ProductPrice pp=new ProductPrice(20000,500,60000);
		System.out.println("___________________Original price___________________");
		pp.display();
		
		pp.UpdatePrice();
		System.out.println("___________________Updated price___________________");
		pp.display();
	}

}
